package com.JarrodRaine.Classes.CSC160.Assignments;

/**
 * @author Jarrod Raine
 */

public class PhoneTester
{	
	public static void main()
	{
		//Creates Phone Objects and displays their specifications
		SmartPhone phone1 = new SmartPhone("Jack's Phone", "Jack's OS", 16.0, 4.5, true, 175.0);
		phone1.displayPhone();
		
		SmartPhone phone2 = new SmartPhone("Jill's Phone", "Jill's OS", 18.0, 5.0, false, 150.0);
		phone2.displayPhone();
		
		SmartPhone phone3 = new SmartPhone("Bob's Phone", "Bob's OS", 20.0, 4.0, false, 160.0);
		phone3.displayPhone();
		
		//Note: A lot of this code below is copied between Highest and Lowest. Only difference is what variables are being checked
		
		//Checks for the Highest Price
		if(phone1.getPrice() > phone2.getPrice() && phone1.getPrice() > phone3.getPrice())
			System.out.println("The most expensive phone is " + phone1.getName() + " at $" + phone1.getPrice());
		if(phone2.getPrice() > phone1.getPrice() && phone2.getPrice() > phone3.getPrice())
			System.out.println("The most expensive phone is " + phone2.getName() + " at $" + phone2.getPrice());
		if(phone3.getPrice() > phone1.getPrice() && phone3.getPrice() > phone2.getPrice())
			System.out.println("The most expensive phone is " + phone3.getName() + " at $" + phone3.getPrice());
		
		//Checks for the Lowest Price
		if(phone1.getPrice() < phone2.getPrice() && phone1.getPrice() < phone3.getPrice())
			System.out.println("The least expensive phone is " + phone1.getName() + " at $" + phone1.getPrice());
		if(phone2.getPrice() < phone1.getPrice() && phone2.getPrice() < phone3.getPrice())
			System.out.println("The least expensive phone is " + phone2.getName() + " at $" + phone2.getPrice());
		if(phone3.getPrice() < phone1.getPrice() && phone3.getPrice() < phone2.getPrice())
			System.out.println("The least expensive phone is " + phone3.getName() + " at $" + phone3.getPrice());
		
		System.out.println();
		
		//Checks for the Highest Capacity
		if(phone1.getCapacity() > phone2.getCapacity() && phone1.getCapacity() > phone3.getCapacity())
			System.out.println("The phone with the most capacity is " + phone1.getName() + " with " + phone1.getCapacity() + " GB");
		if(phone2.getCapacity() > phone1.getCapacity() && phone2.getCapacity() > phone3.getCapacity())
			System.out.println("The phone with the most capacity is " + phone2.getName() + " with " + phone2.getCapacity() + " GB");
		if(phone3.getCapacity() > phone1.getCapacity() && phone3.getCapacity() > phone2.getCapacity())
			System.out.println("The phone with the most capacity is " + phone3.getName() + " with " + phone3.getCapacity() + " GB");
		
		//Checks for the Lowest Capacity
		if(phone1.getCapacity() < phone2.getCapacity() && phone1.getCapacity() < phone3.getCapacity())
			System.out.println("The phone with the least capacity is " + phone1.getName() + " with " + phone1.getCapacity() + " GB");
		if(phone2.getCapacity() < phone1.getCapacity() && phone2.getCapacity() < phone3.getCapacity())
			System.out.println("The phone with the least capacity is " + phone2.getName() + " with " + phone2.getCapacity() + " GB");
		if(phone3.getCapacity() < phone1.getCapacity() && phone3.getCapacity() < phone2.getCapacity())
			System.out.println("The phone with the least capacity is " + phone3.getName() + " with " + phone3.getCapacity() + " GB");
		
		System.out.println();
		
		//Checks for the Highest Display Size
		if(phone1.getDisplaySize() > phone2.getDisplaySize() && phone1.getDisplaySize() > phone3.getDisplaySize())
			System.out.println("The phone with the largest display size is " + phone1.getName() + " with a " + phone1.getDisplaySize() + "in. display");
		if(phone2.getDisplaySize() > phone1.getDisplaySize() && phone2.getDisplaySize() > phone3.getDisplaySize())
			System.out.println("The phone with the largest display size is " + phone2.getName() + " with a " + phone2.getDisplaySize() + "in. display");
		if(phone3.getDisplaySize() > phone1.getDisplaySize() && phone3.getDisplaySize() > phone2.getDisplaySize())
			System.out.println("The phone with the largest display size is " + phone3.getName() + " with a " + phone3.getDisplaySize() + "in. display");
				
		//Checks for the Lowest Display Size
		if(phone1.getDisplaySize() < phone2.getDisplaySize() && phone1.getDisplaySize() < phone3.getDisplaySize())
			System.out.println("The phone with the smallest display size is " + phone1.getName() + " with a " + phone1.getDisplaySize() + "in. display");
		if(phone2.getDisplaySize() < phone1.getDisplaySize() && phone2.getDisplaySize() < phone3.getDisplaySize())
			System.out.println("The phone with the smallest display size is " + phone2.getName() + " with a " + phone2.getDisplaySize() + "in. display");
		if(phone3.getDisplaySize() < phone1.getDisplaySize() && phone3.getDisplaySize() < phone2.getDisplaySize())
			System.out.println("The phone with the smallest display size is " + phone3.getName() + " with a " + phone3.getDisplaySize() + "in. display");
	
		//Checks for Touch ID
		if(phone1.getTouchID())
			System.out.println(phone1.getName() + " has TouchID");
		else
			System.out.println(phone1.getName() + " does not have TouchID");
		if(phone2.getTouchID())
			System.out.println(phone2.getName() + " has TouchID");
		else
			System.out.println(phone2.getName() + " does not have TouchID");
		if(phone3.getTouchID())
			System.out.println(phone3.getName() + " has TouchID");
		else
			System.out.println(phone3.getName() + " does not have TouchID");
		
	}
}